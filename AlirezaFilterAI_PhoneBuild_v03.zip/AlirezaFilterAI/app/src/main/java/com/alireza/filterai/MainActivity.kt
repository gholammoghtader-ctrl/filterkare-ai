package com.alireza.filterai

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var details: TextView

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { showImage(it) }
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            preview.setImageBitmap(bitmap)
            status.text = "تصویر دریافت شد"
            details.text = "برای این نمونه هنوز مدل تشخیص آموزش‌دیده نصب نشده است. لطفاً نتیجه را با بررسی چشمی و آزمون فنی تأیید کنید."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101010.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = value; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(8, 10, 8, 10)
            }

        page.addView(text("علیرضا فیلترکار AI", 26f, 0xFFFF3B30.toInt(), true))
        page.addView(text("کارشناس تصویری فیلتر هوای خودرو", 15f, 0xFFFFFFFF.toInt()))
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF242424.toInt())
            minimumHeight = 260
        }
        page.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        status = text("هنوز تصویری انتخاب نشده", 18f, 0xFFFFFFFF.toInt(), true)
        page.addView(status)
        details = text("از فیلتر عکس بگیرید یا یک تصویر از گالری انتخاب کنید.", 14f, 0xFFCCCCCC.toInt())
        page.addView(details)

        val camera = Button(this).apply {
            text = "📷  عکس گرفتن"
            setOnClickListener { takePhoto.launch(null) }
        }
        val gallery = Button(this).apply {
            text = "🖼  انتخاب از گالری"
            setOnClickListener { pickImage.launch("image/*") }
        }
        page.addView(camera, LinearLayout.LayoutParams(-1, -2))
        page.addView(gallery, LinearLayout.LayoutParams(-1, -2))
        page.addView(text("نسخه آزمایشی ۰٫۱ | تشخیص هوشمند هنوز فعال نیست", 12f, 0xFFFFB74D.toInt()))
        setContentView(page)
    }

    private fun showImage(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                preview.setImageBitmap(BitmapFactory.decodeStream(input))
            }
            status.text = "تصویر انتخاب شد"
            details.text = "این نسخه فقط عکس را نمایش می‌دهد. برای اعلام تمیز، نیمه‌کثیف یا کثیف، باید مدل آموزش‌دیده با نمونه‌های برچسب‌خورده به برنامه اضافه شود."
        } catch (e: Exception) {
            status.text = "خطا در باز کردن تصویر"
            details.text = "لطفاً یک تصویر دیگر انتخاب کنید."
        }
    }
}
